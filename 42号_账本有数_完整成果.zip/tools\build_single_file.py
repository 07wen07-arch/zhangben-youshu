# -*- coding: utf-8 -*-
"""把 web/ 目录打包成一个可直接双击打开的 HTML 单文件。

输入 web/index.html、web/style.css、web/echarts.min.js、web/data.js、web/app.js
输出 账本有数_单文件.html
运行：python tools/build_single_file.py
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'web'
OUT = ROOT / '账本有数_单文件.html'


def esc_script(text):
    """避免 JS 字符串里出现 </script 提前闭合标签。"""
    return re.sub(r'</script', r'<\\/script', text, flags=re.I)


def read(name):
    return (WEB / name).read_text(encoding='utf-8')


def main():
    html = read('index.html')

    css = read('style.css')
    html = html.replace('<link rel="stylesheet" href="style.css">',
                        '<style>\n' + css + '\n</style>')

    for name in ('echarts.min.js', 'data.js', 'app.js'):
        tag = '<script src="%s"></script>' % name
        if tag not in html:
            raise SystemExit('index.html 中找不到脚本标签：' + tag)
        body = esc_script(read(name))
        html = html.replace(tag, '<script>\n' + body + '\n</script>')

    OUT.write_text(html, encoding='utf-8')
    print('已生成：%s（%.1f KB）' % (OUT, OUT.stat().st_size / 1024))


if __name__ == '__main__':
    main()
