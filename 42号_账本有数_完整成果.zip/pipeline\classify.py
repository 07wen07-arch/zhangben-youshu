# -*- coding: utf-8 -*-
"""B 线：规则分类 + 字级朴素贝叶斯 + 准确率评测。

输入 out/clean.json 与 data/04_数据字典与说明/分类规则关键词表.csv
输出 out/classified.json、out/eval.json、out/model.json
运行：python pipeline/classify.py
"""
import csv
import json
import math
import re
import statistics
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'out'
RULES_PATH = ROOT / 'data' / '04_数据字典与说明' / '分类规则关键词表.csv'


def read_rules():
    expense, income = [], []
    fallback = {'支出': '其他', '收入': '工资收入'}
    with open(RULES_PATH, encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            order = (row.get('顺序号') or '').strip()
            cat = (row.get('目标分类') or '').strip()
            raw = (row.get('关键词列表(任一命中即归类)') or '').strip()
            if not cat:
                continue
            if order.startswith('A'):
                bucket = income
            else:
                bucket = expense
            if '无命中' in raw or not raw:
                fallback['收入' if bucket is income else '支出'] = cat
                continue
            keywords = [k.strip().lower() for k in raw.split('|') if k.strip()]
            bucket.append((cat, keywords))
    return expense, income, fallback


EXPENSE_RULES, INCOME_RULES, FALLBACK = read_rules()


def classify(desc, typ='支出'):
    text = (desc or '').lower()
    rules = INCOME_RULES if typ == '收入' else EXPENSE_RULES
    for cat, keywords in rules:
        for kw in keywords:
            if kw in text:
                return cat, kw, 0.97, 'rule'
    return FALLBACK.get(typ, '其他'), '兜底', 0.55, 'fallback'


def tokenize(text):
    text = (text or '').lower()
    chars = re.findall(r'[\u4e00-\u9fff]|[a-z0-9]+', text)
    tokens = list(chars)
    tokens += [chars[i] + chars[i + 1] for i in range(len(chars) - 1)]
    return tokens or ['<empty>']


class NaiveBayes:
    def __init__(self, alpha=1.0):
        self.alpha = alpha

    def fit(self, rows):
        self.labels = sorted({r['category_truth'] for r in rows})
        self.priors = {}
        self.counts = {label: Counter() for label in self.labels}
        self.totals = Counter()
        self.vocab = set()
        for r in rows:
            label = r['category_truth']
            self.priors[label] = self.priors.get(label, 0) + 1
            for tok in tokenize(r['desc']):
                self.counts[label][tok] += 1
                self.totals[label] += 1
                self.vocab.add(tok)
        self.vocab_size = max(1, len(self.vocab))
        self.n = len(rows)

    def predict(self, desc):
        tokens = tokenize(desc)
        best, best_score = None, -1e18
        for label in self.labels:
            score = math.log((self.priors.get(label, 0) + 1) / (self.n + len(self.labels)))
            denom = self.totals[label] + self.alpha * self.vocab_size
            for tok in tokens:
                score += math.log((self.counts[label].get(tok, 0) + self.alpha) / denom)
            if score > best_score:
                best, best_score = label, score
        return best

    def export(self):
        loglik = {}
        for label in self.labels:
            denom = self.totals[label] + self.alpha * self.vocab_size
            loglik[label] = {
                tok: round(math.log((cnt + self.alpha) / denom), 5)
                for tok, cnt in self.counts[label].items()
            }
        return {
            'labels': self.labels,
            # 已平滑的先验，前端可直接复现 predict 的评分
            'priors': {k: round((v + 1) / (self.n + len(self.labels)), 6) for k, v in self.priors.items()},
            'loglik': loglik,
            'vocab_size': self.vocab_size,
            'alpha': self.alpha,
            'totals': dict(self.totals),
        }


def stratified_folds(rows, k=5):
    """分层 K 折：每个折内各标签比例接近，避免小类别被切空。"""
    by_label = defaultdict(list)
    for i, r in enumerate(rows):
        by_label[r['category_truth']].append(i)
    folds = [[] for _ in range(k)]
    for label, idxs in sorted(by_label.items()):
        for j, i in enumerate(idxs):
            folds[j % k].append(i)
    return folds


def metrics(test, preds):
    labels = sorted({r['category_truth'] for r in test})
    per_class = []
    for label in labels:
        tp = sum(1 for r, p in zip(test, preds) if r['category_truth'] == label and p == label)
        fp = sum(1 for r, p in zip(test, preds) if r['category_truth'] != label and p == label)
        fn = sum(1 for r, p in zip(test, preds) if r['category_truth'] == label and p != label)
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        per_class.append({'cat': label, 'precision': round(precision, 4),
                          'recall': round(recall, 4), 'f1': round(f1, 4), 'n': tp + fn})
    confusion = defaultdict(lambda: defaultdict(int))
    for r, p in zip(test, preds):
        confusion[r['category_truth']][p] += 1
    return per_class, {k: dict(v) for k, v in confusion.items()}


def main():
    payload = json.loads((OUT / 'clean.json').read_text(encoding='utf-8'))
    datasets = payload['datasets']
    all_rows = [t for d in datasets for t in d['txns']]

    classified = {}
    rule_hits = 0
    for d in datasets:
        mapping = {}
        for t in d['txns']:
            cat, kw, conf, engine = classify(t['desc'], t['type'])
            mapping[t['txn_id']] = {'pred': cat, 'rule_hit': kw, 'confidence': conf, 'engine': engine}
            rule_hits += int(cat == t['category_truth'])
        classified[d['id']] = mapping
    rule_acc = rule_hits / len(all_rows) if all_rows else 0.0

    k = 5
    folds = stratified_folds(all_rows, k)
    oof_rows, oof_preds, fold_accs = [], [], []
    for fi in range(k):
        test_idx = set(folds[fi])
        train = [r for i, r in enumerate(all_rows) if i not in test_idx]
        test = [all_rows[i] for i in folds[fi]]
        model = NaiveBayes()
        model.fit(train)
        preds = [model.predict(r['desc']) for r in test]
        correct = sum(1 for r, p in zip(test, preds) if r['category_truth'] == p)
        fold_accs.append(round(correct / len(test), 4) if test else 0.0)
        oof_rows.extend(test)
        oof_preds.extend(preds)
    model_acc = sum(fold_accs) / k
    model_std = statistics.pstdev(fold_accs)
    per_class, confusion = metrics(oof_rows, oof_preds)

    # 导出前端推理用的模型用全量样本训练（评测另走交叉验证，互不污染）
    full_model = NaiveBayes()
    full_model.fit(all_rows)

    eval_payload = {
        'rule_accuracy': round(rule_acc, 4),
        'model_accuracy': round(model_acc, 4),
        'model_accuracy_std': round(model_std, 4),
        'cv_k': k,
        'fold_accuracies': fold_accs,
        'test_size': int(round(len(all_rows) / k)),
        'train_size': len(all_rows) - int(round(len(all_rows) / k)),
        'n': len(all_rows),
        'per_class': per_class,
        'confusion': confusion,
        'features': '描述的字级 unigram + bigram，未使用任何标签列',
        'note': '5 折分层交叉验证；准确率为各折均值，每类 P/R/F1 与混淆矩阵基于折外预测合并。',
    }
    (OUT / 'classified.json').write_text(json.dumps(classified, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'eval.json').write_text(json.dumps(eval_payload, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'model.json').write_text(json.dumps(full_model.export(), ensure_ascii=False), encoding='utf-8')

    print('样本 %d 笔 | %d 折交叉验证' % (len(all_rows), k))
    print('规则分类准确率: %.2f%%' % (rule_acc * 100))
    print('朴素贝叶斯 %d 折: %s' % (k, ' / '.join('%.2f%%' % (a * 100) for a in fold_accs)))
    print('朴素贝叶斯均值: %.2f%% ± %.2f%%' % (model_acc * 100, model_std * 100))
    print('规则覆盖（非兜底）: %d / %d' % (
        sum(1 for d in datasets for t in d['txns'] if classified[d['id']][t['txn_id']]['engine'] == 'rule'), len(all_rows)))
    print('已写出 classified.json / eval.json / model.json')
    assert rule_acc >= 0.85 and model_acc >= 0.85, '分类准确率未达到 85%'


if __name__ == '__main__':
    main()
